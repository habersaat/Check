

## ==> GUI FILE
from main import *

class Functions(MainWindow):
    pass
